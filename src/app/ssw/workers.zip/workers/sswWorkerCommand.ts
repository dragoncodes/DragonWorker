export class SswWorkerCommand {

    private static POST_MESSAGE_TEMPLATE: string = "self.postMessage({1});";

    private innerFunctionMap: { start: number, end: number }[]

    public functionName: string;

    constructor(private fn: Function) {
        this.innerFunctionMap = [];
    }

    toCommandString(): string {
        let originalFunction: string = this.fn.toString();

        originalFunction = this.handleAnomFunctions(originalFunction);
        originalFunction = this.replaceReturnValues(originalFunction);
        originalFunction = this.plugParameters(originalFunction);

        return originalFunction;
    }

    // private functionsCount(functionBody: string): number {
    //     return functionBody.split("function").length - 1;
    // }

    private returnCount(functionBody: string): number {
        return functionBody.split("return").length - 1;
    }

    private plugParameters(originalFunction: string): string {
        let newFunction = `
            self.onmessage = (e) => {
                ` + this.functionName + "(... e.data);" + `
            };
        `;

        return originalFunction + newFunction;
    }

    // private indexWithinInnerFunction(index: number): boolean {

    //     for (var i = 0; i < this.innerFunctionMap.length; i++) {
    //         var innerFunction = this.innerFunctionMap[i];

    //         if (innerFunction.start <= index && innerFunction.end >= index) {
    //             return true;
    //         }
    //     }

    //     return false;
    // }

    private replaceReturnValues(originalFunction: string): string {
        let returnCount: number = this.returnCount(originalFunction);

        if (returnCount > 0) {
            let returnIndex: number = originalFunction.indexOf("return");

            while (returnCount > 0) {

                let returnValue: string = "";
                for (let i: number = returnIndex + "return ".length; i < originalFunction.length; i++) {
                    if (originalFunction[i] !== ';') {
                        returnValue += originalFunction[i];
                    } else {
                        break;
                    }
                }

                originalFunction = originalFunction.replace(("return " + returnValue + ";"), SswWorkerCommand.POST_MESSAGE_TEMPLATE.replace("{1}", returnValue));
                returnIndex++;

                returnIndex = originalFunction.indexOf("return");
                returnCount--;
            }
        }

        return originalFunction;
    }

    // private handleMultipleFunctions(originalFunction: string): string {
    //     let functionsCount: number = this.functionsCount(originalFunction);

    //     if (functionsCount > 1) {
    //         // Multiple functions
    //         let functionTemplate: string = "function";

    //         let mainFunctionIndex: number = originalFunction.indexOf(functionTemplate);
    //         let innerFunctionIndex = originalFunction.indexOfAfter(functionTemplate, mainFunctionIndex);

    //         // Build a map of all innerFunctions
    //         this.innerFunctionMap.push({ start: innerFunctionIndex, end: originalFunction.indexOfAfter('}', innerFunctionIndex) });
    //     }

    //     originalFunction = this.handleAnomFunctions(originalFunction);

    //     return originalFunction;
    // }

    private handleAnomFunctions(originalFunction: string): string {
        let functionDeclarationIndex: number = originalFunction.indexOf("function");

        let index = functionDeclarationIndex + "function".length;
        let functionName: string = "";
        while (originalFunction[index] !== '(') {
            functionName += originalFunction[index];
            index++;
        }

        if (functionName.trim() === "") {

            functionName = "SswWorker" + Date.now();
            originalFunction = originalFunction.slice(0, index) + functionName + originalFunction.slice(index, originalFunction.length);
        }

        this.functionName = functionName;

        return originalFunction;
    }
}
