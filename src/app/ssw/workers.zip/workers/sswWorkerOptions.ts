import { NgZone } from "angular2/core";

export interface SswWorkerOptions {
    noAutoTerminate?: boolean;
    doneCallback: Function;
    workerArguments?: any[];
    elapsedTime?: boolean;
    contextZone?: NgZone;
}
