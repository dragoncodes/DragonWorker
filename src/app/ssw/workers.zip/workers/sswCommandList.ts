import { SswWorkerCommand } from "./sswWorkerCommand";

export class SswCommandList {

    private commandList: SswWorkerCommand[];
    private workerBody: string;

    constructor() {
        this.commandList = [];
    }

    public addCommand(command: Function): void {
        // this.commandList.push( command );
        let workerCommand = new SswWorkerCommand( command );


    }

}
