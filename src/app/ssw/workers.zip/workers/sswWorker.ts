import { SswWorkerCommand } from "./sswWorkerCommand";
import { SswWorkerOptions } from "./sswWorkerOptions";

export interface SswWorkerResponse {
    originalEvent: MessageEvent;
    data: any;
    elapsedTime?: number;
}

export class SswWorker {

    private static POST_MESSAGE_COMMAND = "self.postMessage( 'Post message not specified' )";

    public static runCode(codeToRun: string[] | Function, options: SswWorkerOptions): void | Worker {

        let workerArguments = options.workerArguments;

        if (!options.doneCallback) {
            throw new Error("<SswWorkerOptions>.doneCallback not defined !");
        }

        if (codeToRun instanceof Function) {
            codeToRun = [new SswWorkerCommand(codeToRun as Function).toCommandString()];
        }

        codeToRun = SswWorker.ensureWorkerCorrectness(codeToRun as string[]);

        let codeBlobUrl = URL.createObjectURL(new Blob(codeToRun as string[]));
        let worker = new Worker(codeBlobUrl);
        let startTime: number;

        worker.onmessage = (e) => {

            if (options.noAutoTerminate !== true) {
                worker.terminate();
            }

            let returnArgs: SswWorkerResponse = {
                originalEvent: e,
                data: e.data
            };

            if (options.elapsedTime === true) {
                returnArgs.elapsedTime = Date.now() - startTime;
            }

            if (options.contextZone !== null) {
                options.contextZone.run(() => {
                    options.doneCallback(returnArgs);
                });
            }
        };

        if (options.elapsedTime === true) {
            startTime = Date.now();
        }

        worker.postMessage(workerArguments ? workerArguments : "start");

        if (options.noAutoTerminate !== true) {
            return worker;
        }
    }

    private static ensureWorkerCorrectness(args: string[]): string[] {

        let hasPostMessage: boolean = false;

        for (var i = 0; i < args.length; i++) {
            var command = args[i];

            if (command.indexOf(SswWorker.POST_MESSAGE_COMMAND)) {
                hasPostMessage = true;
            }
        }

        if (!hasPostMessage) {
            throw new Error("Worker doesn't have return or postMessage()");
        }

        return args;
    }
}
